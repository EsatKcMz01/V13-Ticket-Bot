# Discord.js v13 Simple Ticket bot | Quick.db
### Features
- Slash Commands
- Buttons
- Quick.db

## Setup
```
npm install
```

## How to use?
**You can fork the repl [here](https://replit.com/@CodyDimensions/Discordjs-v13-Ticket-bot-or-Quickdb)**

**Clone the repositories:**
``` 
git clone https://github.com/CodyDimensions/Discord.js-v13-Ticket-bot-Quick.db
```


### Subscribe our YouTube Channel
[Cody Dimensions Youtube channel](https://www.youtube.com/channel/UChCwEZuaY3fsYRLp5WZ3ZJg)
Remember to like and share our videos!

### Discord Server
[Click here to join Cody Dimensions Server](https://discord.gg/D8RPg7YSJv)